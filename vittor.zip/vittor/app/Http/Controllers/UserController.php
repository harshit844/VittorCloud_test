<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Auth, Validator, DB;
use Brian2694\Toastr\Facades\Toastr;

class UserController extends Controller
{
    public function show(){
        $user = auth()->user();
        return view('users.edit', compact('user'));
    }
    
    public function update(request $request){
        $data = $request->all();
        $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'dob' => ['required']
        ]);

        $user = User::updateOrCreate(
            [
                'id' => auth()->user()->id
            ],
            [
                'first_name' => @$data['first_name'],
                'last_name' => @$data['last_name'],
                'dob' => @$data['dob'],
            ]
        );

        Toastr::success('User Successfully Updated','Success');
        return redirect()->route('home');
    }

    public function logOut(){
        Auth::logout();
        return redirect('/login');
    }
}
