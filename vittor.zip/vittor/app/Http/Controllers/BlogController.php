<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\Blog;

class BlogController extends Controller
{
    public function index(){
        $blogs = Blog::where('user_id', auth()->user()->id)->get();
        return view('blogs.index', compact('blogs'));
    }
}
