@extends('layouts.app')

@section('content')
<main class="app-content">
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h3 class="tile-title">Blogs</h3>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Title</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
              @if($blogs)
                @php $i = 0; @endphp
                @foreach($blogs as $rs)
                  <tr>
                    <td>{{ ++$i }}</td>
                    <td>{{ @$rs->title }}</td>
                    <td>{{ @$rs->description }}</td>
                  </tr>
                @endforeach
              @endif
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</main>
@endsection