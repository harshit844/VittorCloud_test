@extends('layouts.app')

@section('content')
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Edit Profile</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <a class="btn btn-sm btn-warning" href="javascript:window.history.back();">Back</a>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <form method="post" id="userFrm" action="{{ route('user.update') }}">
                    @csrf
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input class="form-control @error('first_name') is-invalid @enderror" id="first_name" type="text" name="first_name" placeholder="Enter first name" value="{{ auth()->user()->first_name }}">
                        @error('first_name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input class="form-control @error('last_name') is-invalid @enderror" id="last_name" name="last_name" type="text" placeholder="Enter last name" value="{{ auth()->user()->last_name }}">
                        @error('last_name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="dob">DOB</label>
                        <input class="form-control @error('dob') is-invalid @enderror" id="dob" type="text" name="dob" value="{{ auth()->user()->dob }}">
                        @error('dob')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input class="form-control" id="email" type="email" placeholder="Enter email" value="{{ auth()->user()->email }}" disabled>
                    </div>
                    <div class="tile-footer">
                        <button class="btn btn-primary" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
@stop

@section('scripts')
<script>
    $(document).ready(function(){
        $("#dob").datepicker({
            format: "yyyy-mm-dd",
            weekStart: 0,
            calendarWeeks: true,
            autoclose: true,
            todayHighlight: true,
            rtl: true,
            orientation: "auto"
        });

        // $("#userFrm").validate({
        //     debug: true,
        //     rules: {
        //         first_name: {
        //             required: true,
        //             minLength: 2,
        //             maxLength: 20
        //         },
        //         last_name: {
        //             required: true,
        //             minLength: 2,
        //             maxLength: 20
        //         },
        //         dob: {
        //             required: true
        //         },
        //         email: {
        //             required: true,
        //             email: true
        //         }
        //     },
        //     message: {
        //         first_name: "Please enter first name",
        //         last_name: "Please enter last name",
        //         email: "Please enter email",
        //         dob: "Please select your dob"
        //     }
        // });
    });
</script>
@stop